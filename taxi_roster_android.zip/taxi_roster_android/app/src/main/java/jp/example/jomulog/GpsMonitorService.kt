package jp.example.jomulog
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.*
import com.google.android.gms.location.*

class GpsMonitorService:Service(){
 private val p by lazy{getSharedPreferences("jomu",MODE_PRIVATE)}
 private val client by lazy{LocationServices.getFusedLocationProviderClient(this)}
 private var callback:LocationCallback?=null
 private var last:Location?=null
 private var stillSince=0L
 private var candidateRaised=false
 private val channel="jomu_gps"
 override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel(channel,"乗務中GPS監視",NotificationManager.IMPORTANCE_LOW));nm.createNotificationChannel(NotificationChannel("jomu_alert","休憩候補",NotificationManager.IMPORTANCE_HIGH))}}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  val n=Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("乗務ログ・GPS監視中").setContentText("画面ロック中も停車状態を監視しています").setOngoing(true).build()
  if(Build.VERSION.SDK_INT>=29)startForeground(3001,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(3001,n)
  p.edit().putBoolean("gps",true).putString("gpsMsg","画面ロック中も位置情報を監視中").apply()
  val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,10000L).setMinUpdateIntervalMillis(5000L).setMinUpdateDistanceMeters(5f).build()
  callback=object:LocationCallback(){override fun onLocationResult(r:LocationResult){r.lastLocation?.let{process(it)}}}
  try{client.requestLocationUpdates(req,callback!!,mainLooper)}catch(e:SecurityException){p.edit().putBoolean("gps",false).putString("gpsMsg","位置情報の権限がありません").apply();stopSelf()}
  return START_STICKY
 }
 private fun process(loc:Location){
  val t=if(loc.time>0)loc.time else System.currentTimeMillis()
  p.edit().putString("acc","約${loc.accuracy.toInt()}m").apply()
  if(loc.accuracy>60f){p.edit().putString("gpsMsg","GPS精度が不十分なため判定を保留").apply();last=loc;return}
  val prev=last;var stopped=false
  if(prev!=null){val d=prev.distanceTo(loc);val speed=if(loc.hasSpeed())loc.speed else -1f
   stopped=d<=maxOf(20f,minOf(loc.accuracy,35f))&&(speed<1.5f)
   if(d>45f||speed>2.5f){stillSince=0L;candidateRaised=false;p.edit().putString("gpsMsg","走行を検知しました").apply()}}
  if(stopped){if(stillSince==0L)stillSince=t;val duration=t-stillSince
   p.edit().putString("gpsMsg","停車を検知中：約${duration/60000}分").apply()
   if(duration>=15*60*1000L&&!candidateRaised&&!p.getBoolean("candidate",false)){
    candidateRaised=true;p.edit().putLong("cs",stillSince).putLong("ce",t).putBoolean("candidate",true).putString("gpsMsg","15分以上停車：休憩候補を確認してください").apply()
    val nm=getSystemService(NotificationManager::class.java)
    val pi=PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    nm.notify(3002,Notification.Builder(this,"jomu_alert").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("乗務ログ：休憩候補").setContentText("15分以上停車しています。休憩かどうか確認してください。").setContentIntent(pi).setAutoCancel(true).build())
   }else if(p.getBoolean("candidate",false))p.edit().putLong("ce",t).apply()
  }
  last=loc
 }
 override fun onDestroy(){callback?.let{client.removeLocationUpdates(it)};p.edit().putBoolean("gps",false).putString("gpsMsg","GPS監視は停止しています").apply();super.onDestroy()}
 override fun onBind(intent:Intent?)=null
}
