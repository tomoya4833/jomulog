package jp.example.jomulog
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: Activity() {
 private val p by lazy { getSharedPreferences("jomu",MODE_PRIVATE) }
 private lateinit var status:TextView; private lateinit var stats:TextView; private lateinit var gps:TextView; private lateinit var candidate:TextView
 private lateinit var start:Button; private lateinit var end:Button; private lateinit var gpsStart:Button; private lateinit var gpsStop:Button; private lateinit var yes:Button; private lateinit var no:Button
 private val handler=Handler(Looper.getMainLooper())
 private val loop=object:Runnable { override fun run(){render();handler.postDelayed(this,1000)} }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);build();askPermissions();handler.post(loop)}
 override fun onDestroy(){handler.removeCallbacks(loop);super.onDestroy()}
 private fun build(){
  val scroll=ScrollView(this); val l=LinearLayout(this).apply{orientation=1;setPadding(30,28,30,24);setBackgroundColor(0xFFF3F6F8.toInt())}
  fun label(t:String,size:Float=16f)=TextView(this).apply{text=t;textSize=size;setTextColor(0xFF172B3A.toInt());setPadding(0,10,0,10)}
  fun btn(t:String, f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
  l.addView(label("🚕 乗務ログ",27f));l.addView(label("タクシー労務管理・隔日勤務",14f))
  status=label("");l.addView(status);stats=label("");l.addView(stats)
  start=btn("出庫・勤務開始"){startShift()};l.addView(start)
  end=btn("帰庫・勤務終了"){endShift()};l.addView(end)
  gps=label("GPS監視：停止中");l.addView(gps)
  gpsStart=btn("バックグラウンドGPS監視を開始"){startGps()};l.addView(gpsStart)
  gpsStop=btn("GPS監視を停止"){stopGps()};l.addView(gpsStop)
  l.addView(label("15分以上の停車候補",19f));candidate=label("候補はありません");l.addView(candidate)
  yes=btn("休憩だった・加算する"){review(true)};l.addView(yes)
  no=btn("業務待機だった・加算しない"){review(false)};l.addView(no)
  l.addView(label("画面ロック中も通知欄にGPS監視中の通知を表示します。GPS精度やOSの省電力設定により検知が止まる場合があります。停車だけで法令上の休憩とは確定できないため、候補は必ず確認してください。",12f))
  scroll.addView(l);setContentView(scroll)
 }
 private fun askPermissions(){
  val a=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
  if(Build.VERSION.SDK_INT>=33)a.add(Manifest.permission.POST_NOTIFICATIONS)
  if(Build.VERSION.SDK_INT>=29)a.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
  val missing=a.filter{checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED}
  if(missing.isNotEmpty())requestPermissions(missing.toTypedArray(),9)
 }
 private fun startShift(){if(p.getLong("out",0)>0&&p.getLong("in",0)==0L){toast("すでに乗務中です");return}
  p.edit().putString("date",date()).putLong("out",System.currentTimeMillis()).putLong("in",0).putLong("breaks",0).putBoolean("candidate",false).apply();render()}
 private fun endShift(){p.edit().putLong("in",System.currentTimeMillis()).apply();stopGps();render()}
 private fun startGps(){if(p.getLong("out",0)==0L||p.getLong("in",0)>0){toast("先に出庫を記録してください");return}
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){askPermissions();return}
  val i=Intent(this,GpsMonitorService::class.java);if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i)}
 private fun stopGps(){stopService(Intent(this,GpsMonitorService::class.java));p.edit().putBoolean("gps",false).apply();render()}
 private fun review(add:Boolean){if(!p.getBoolean("candidate",false)){toast("確認する候補はありません");return}
  val s=p.getLong("cs",0);val e=p.getLong("ce",System.currentTimeMillis())
  if(add&&e>s){p.edit().putLong("breaks",p.getLong("breaks",0)+(e-s)).apply();toast("休憩時間に加算しました")}else toast("休憩には加算しません")
  p.edit().putBoolean("candidate",false).apply();render()}
 private fun render(){val o=p.getLong("out",0);val i=p.getLong("in",0);val now=if(i>0)i else System.currentTimeMillis();val elapsed=if(o>0)now-o else 0
  status.text="乗務日：${p.getString("date",date())}\n出庫：${if(o>0)time(o) else "--:--"}　帰庫：${if(i>0)time(i) else "--:--"}\n状態：${if(o==0L)"勤務前" else if(i>0)"帰庫済み" else "乗務中"}"
  val b=p.getLong("breaks",0);stats.text="拘束時間：${dur(elapsed)}\n確認済み休憩：${dur(b)}\n控除後（参考）：${dur((elapsed-b).coerceAtLeast(0))}"
  gps.text="GPS監視：${if(p.getBoolean("gps",false))"稼働中" else "停止中"}\n${p.getString("gpsMsg","出庫後にGPS監視を開始してください")}\n位置精度：${p.getString("acc","未取得")}"
  start.isEnabled=o==0L||i>0;end.isEnabled=o>0&&i==0L;gpsStart.isEnabled=o>0&&i==0L&&!p.getBoolean("gps",false);gpsStop.isEnabled=p.getBoolean("gps",false)
  val c=p.getBoolean("candidate",false);candidate.text=if(c)"停車：約${dur(p.getLong("ce",System.currentTimeMillis())-p.getLong("cs",0))}\n開始：${time(p.getLong("cs",0))}　終了：${time(p.getLong("ce",System.currentTimeMillis()))}\nこの時間は実際に休憩でしたか？" else "候補はありません";yes.isEnabled=c;no.isEnabled=c
 }
 private fun date()=SimpleDateFormat("yyyy-MM-dd",Locale.JAPAN).format(Date())
 private fun time(ms:Long)=SimpleDateFormat("HH:mm",Locale.JAPAN).format(Date(ms))
 private fun dur(ms:Long):String{val m=(ms.coerceAtLeast(0)/60000).toInt();return "${m/60}時間${(m%60).toString().padStart(2,'0')}分"}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
